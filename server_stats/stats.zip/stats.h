#pragma once

#include "http_request.h"

#include <string_view>
#include <map>

using namespace std;

class Stats {
public:
    Stats();
//    Stats() {
//        method_stats["GET"] = 0;
//        method_stats["POST"] = 0;
//        method_stats["PUT"] = 0;
//        method_stats["DELETE"] = 0;
//        method_stats["UNKNOWN"] = 0;
//
//        uri_stats["/"] = 0;
//        uri_stats["/order"] = 0;
//        uri_stats["/product"] = 0;
//        uri_stats["/basket"] = 0;
//        uri_stats["/help"] = 0;
//        uri_stats["unknown"] = 0;
//    }

    void AddMethod(string_view method);
//    void AddMethod(string_view method) {
//        if (method == "GET") {
//            method_stats["GET"]++;
//        } else if (method == "POST") {
//            method_stats["POST"]++;
//        } else if (method == "PUT") {
//            method_stats["PUT"]++;
//        } else if (method == "DELETE") {
//            method_stats["DELETE"]++;
//        } else {
//            method_stats["UNKNOWN"]++;
//        }
//    }
    void AddUri(string_view uri);
//    void AddUri(string_view uri) {
//        if (uri == "/") {
//            uri_stats["/"]++;
//        } else if (uri == "/order") {
//            uri_stats["/order"]++;
//        } else if (uri == "/product") {
//            uri_stats["/product"]++;
//        } else if (uri == "/basket") {
//            uri_stats["/basket"]++;
//        } else if (uri == "/help") {
//            uri_stats["/help"]++;
//        } else {
//            uri_stats["unknown"]++;
//        }
//    }

    const map<string_view, int> &GetMethodStats() const;

    const map<string_view, int> &GetUriStats() const;

private:
    map<string_view, int> method_stats;
    map<string_view, int> uri_stats;
};

HttpRequest ParseRequest(string_view line);